import re
import xbmc
import json

if xbmc.getCondVisibility('system.platform.android') :
    import androidsslPy
    AES=androidsslPy._load_crypto_libcrypto()
else:
    from Crypto.Cipher import AES
    
from Crypto.Util import Counter





import os
import random
import binascii
import requests
import errors
import time
from cryptotools import *


def singleton(cls):
    obj = cls()
    # Always return the same object
    cls.__new__ = staticmethod(lambda cls: obj)
    # Disable __init__
    try:
        del cls.__init__
    except AttributeError:
        pass
    return cls
  
@singleton  
class Mega(object):
    
    def __init__(self):
        self.schema = 'https'
        self.domain = 'mega.co.nz'
        self.timeout = 160 #max time (secs) to wait for resp from api requests
        self.sid = None
        self.sequence_num = random.randint(0, 0xFFFFFFFF)
        self.request_id = make_id(10)
        self.speed = 0.0
        self.pause= False
        
    def getSpeed(self):
        return self.speed

            
    def api_request(self, data):
        params = {'id': self.sequence_num}
        self.sequence_num += 1

        if self.sid:
            params.update({'sid': self.sid})
        req = requests.post(
            '{0}://g.api.{1}/cs'.format(self.schema, self.domain),
                                        params=params,
                                        data=json.dumps([data]),
                                        timeout=self.timeout)

        json_resp = json.loads(req.text)

        #if numeric error code response
        if isinstance(json_resp, int):
            raise errors.RequestError(json_resp)
        return json_resp[0]

    def get_files(self):
        '''
        Get all files in account
        '''
        files = self.api_request({'a': 'f', 'c': 1})

        files_dict = {}
        for file in files['f']:
            #print "file="+repr(file)
            processed_file = self.process_file(file)
            #ensure each file has a name before returning
            if processed_file['a']:
                files_dict[file['h']] = processed_file

                #print "file[h]="+repr(file['h'])
                #print "-> "+repr(files_dict[file['h']])

        return files_dict


    def convertSomeShit(self,theShit):
        return base64_to_a32(theShit)
    
    def SecondConvertSomeShit(self,theShit):
        return base64_url_decode(theShit)
    
    def get_link(self, file):
        '''
        Get a file public link from given file object
        '''
        #print "file=",file
        file = file[1]
        if 'h' in file and 'k' in file:
            public_handle = self.api_request({'a': 'l', 'n': file['h']})
            file_key = file['k'][file['k'].index(':') + 1:]
            decrypted_key = a32_to_base64(decrypt_key(base64_to_a32(file_key),
                                                      self.master_key))
            return '{0}://{1}/#!{2}!{3}'.format(self.schema,
                                                self.domain,
                                                public_handle,
                                                decrypted_key)
        else:
            raise errors.ValidationError('File id and key must be present')


    def download_url(self, url, dest_path=None, dest_filename='Play.3D.SBS.mkv'):
        """
        Download a file by it's public url
        """
        path = self._parse_url(url).split('!')
        file_id = path[0]
        file_key = path[1]
        self._download_file(file_id, file_key, dest_path, dest_filename, is_public=True)
        
    def download_url_torrent(self, url, dest_path=None, dest_filename='Play.3D.SBS.mkv'):
        """
        Download a file by it's public url
        """
        path = self._parse_url(url).split('!')
        file_id = path[0]
        file_key = path[1]
        self._download_torrent(file_id, file_key, dest_path, dest_filename, is_public=True)
        
    def download(self, file, dest_path=None):
        '''
        Download a file by it's file object
        '''
        url = self.get_link(file)
        self.download_url(url, dest_path)

    def parse_url(self, url):
        #parse file id and key from url
        if ('!' in url):
            match = re.findall(r'/#!(.*)', url)
            path = match[0]
            return path
        else:
            raise errors.RequestError('Url key missing')
    
    def file_details(self, file_handle, file_key, is_public=True):
        if is_public:
            file_key = base64_to_a32(file_key)
            file_data = self.api_request({'a': 'g', 'g': 1, 'p': file_handle})
        else:
            file_data = self.api_request({'a': 'g', 'g': 1, 'n': file_handle})

        k = (file_key[0] ^ file_key[4], file_key[1] ^ file_key[5],
             file_key[2] ^ file_key[6], file_key[3] ^ file_key[7])
        iv = file_key[4:6] + (0, 0)
        meta_mac = file_key[6:8]

        file_url = file_data['g']
        file_size = file_data['s']
        attribs = base64_url_decode(file_data['at'])
        attribs = decrypt_attr(attribs, k)
        temp_file_name = attribs['n']
        file_name = 'Play.3D.SBS'+temp_file_name[len(temp_file_name)-4:]

        return {'size':file_size,'name':temp_file_name}
    
    def human_size(self,size):
        size = float(size)
        if size<1024:
            text_size="%sB" % format(size,'.2f')
        elif size<(1024*1024):
            text_size="%sKB" % format((size / float(1024.0)),'.2f')
        elif size<(1024*1024*1024):
            text_size="%sMB" % format((size / float(1024.0*1024.0) ),'.2f')
        elif size<(1024*1024*1024*1024):
            text_size="%sGB" % format((size / float(1024.0*1024.0*1024.0) ),'.2f')
        else:
            text_size="%sTB" % format((size / float(1024.0*1024.0*1024.0*1024.0) ),'.2f')
    
        return text_size

    def _api_request(self, data):
        params = {'id': self.sequence_num}
        self.sequence_num += 1

        if self.sid:
            params.update({'sid': self.sid})

        #ensure input data is a list
        if not isinstance(data, list):
            data = [data]

        req = requests.post(
            '{0}://g.api.{1}/cs'.format(self.schema, self.domain),
            params=params,
            data=json.dumps(data),
            timeout=self.timeout)
        json_resp = json.loads(req.text)

        #if numeric error code response
        if isinstance(json_resp, int):
            raise RequestError(json_resp)
        return json_resp[0]
    
    def _download_file(self, file_handle, file_key, dest_path=None, dest_filename=None, is_public=False, file=None):
        if file is None:
            if is_public:
                file_key = base64_to_a32(file_key)
                file_data = self._api_request({'a': 'g', 'g': 1, 'p': file_handle})
            else:
                file_data = self._api_request({'a': 'g', 'g': 1, 'n': file_handle})

            k = (file_key[0] ^ file_key[4], file_key[1] ^ file_key[5],
                 file_key[2] ^ file_key[6], file_key[3] ^ file_key[7])
            iv = file_key[4:6] + (0, 0)
            meta_mac = file_key[6:8]
        else:
            file_data = self._api_request({'a': 'g', 'g': 1, 'n': file['h']})
            k = file['k']
            iv = file['iv']
            meta_mac = file['meta_mac']

        if 'g' not in file_data:
            raise RequestError('File not accessible anymore')
        file_url = file_data['g']
        file_size = file_data['s']
        attribs = base64_url_decode(file_data['at'])
        attribs = decrypt_attr(attribs, k)
        temp_file_name = attribs['n']
        file_name = 'Play.3D.SBS'+temp_file_name[len(temp_file_name)-4:]

        print "downloading {0} (size: {1}), url = {2}".format(attribs['n'].encode("utf8"),
                                                              file_size,
                                                              file_url)

        if dest_path:
            output_file_name = dest_path + file_name
        else:
            output_file_name = file_name
            
        input_file = requests.get(file_url, stream=True).raw
        output_file = open(output_file_name,'wb')

        k_str = a32_to_str(k)
        counter = Counter.new(
            128, initial_value=((iv[0] << 32) + iv[1]) << 64)
        aes = AES.new(k_str, AES.MODE_CTR, counter=counter)

        mac_str = '\0' * 16
        mac_encryptor = AES.new(k_str, AES.MODE_CBC, mac_str)
        iv_str = a32_to_str([iv[0], iv[1], iv[0], iv[1]])
        forced_stop = False
        forced_stop_file = os.path.join( dest_path , "force_stop.tmp" )
        start = time.clock()
        dl = 0
        for chunk_start, chunk_size in sorted(get_chunks(file_size).items()):

            if os.path.exists( forced_stop_file ):
                forced_stop = True
                print "Forced stop"
                break

            chunk = input_file.read(chunk_size)
            chunk = aes.decrypt(chunk)
            output_file.write(chunk)
            
            encryptor = AES.new(k_str, AES.MODE_CBC, iv_str)
            dl += len(chunk)
            
            for i in range(0, len(chunk)-16, 16):
                block = chunk[i:i + 16]
                encryptor.encrypt(block)

            #fix for files under 16 bytes failing
            if file_size > 16:
                i += 16
            else:
                i = 0

            block = chunk[i:i + 16]
            if len(block) % 16:
                block += '\0' * (16 - (len(block) % 16))
            mac_str = mac_encryptor.encrypt(encryptor.encrypt(block))
            self.speed = float(float(dl)//float(time.clock() - start))
        file_mac = str_to_a32(mac_str)
        
        output_file.close()
        # check mac integrity
        #if (file_mac[0] ^ file_mac[1], file_mac[2] ^ file_mac[3]) != meta_mac:
        #    raise ValueError('Mismatched mac')
        
        if not forced_stop:
            pass
            # check mac integrity
            #if (file_mac[0] ^ file_mac[1], file_mac[2] ^ file_mac[3]) != meta_mac:
            #    raise ValueError('Mismatched mac')
        else:
            os.remove(forced_stop_file)
            os.remove(output_file_name)

    def _download_torrent(self, file_handle, file_key, dest_path=None, dest_filename=None, is_public=False, file=None):
        if file is None:
            if is_public:
                file_key = base64_to_a32(file_key)
                file_data = self._api_request({'a': 'g', 'g': 1, 'p': file_handle})
            else:
                file_data = self._api_request({'a': 'g', 'g': 1, 'n': file_handle})

            k = (file_key[0] ^ file_key[4], file_key[1] ^ file_key[5],
                 file_key[2] ^ file_key[6], file_key[3] ^ file_key[7])
            iv = file_key[4:6] + (0, 0)
            meta_mac = file_key[6:8]
        else:
            file_data = self._api_request({'a': 'g', 'g': 1, 'n': file['h']})
            k = file['k']
            iv = file['iv']
            meta_mac = file['meta_mac']

        if 'g' not in file_data:
            raise RequestError('File not accessible anymore')
        file_url = file_data['g']
        file_size = file_data['s']
        attribs = base64_url_decode(file_data['at'])
        attribs = decrypt_attr(attribs, k)
        temp_file_name = attribs['n']
        file_name = 'play.torrent'

        print "downloading {0} (size: {1}), url = {2}".format(attribs['n'].encode("utf8"),
                                                              file_size,
                                                              file_url)

        if dest_path:
            output_file_name = dest_path + file_name
        else:
            output_file_name = file_name
            
        input_file = requests.get(file_url, stream=True).raw
        output_file = open(output_file_name,'wb')

        k_str = a32_to_str(k)
        counter = Counter.new(
            128, initial_value=((iv[0] << 32) + iv[1]) << 64)
        aes = AES.new(k_str, AES.MODE_CTR, counter=counter)

        mac_str = '\0' * 16
        mac_encryptor = AES.new(k_str, AES.MODE_CBC, mac_str)
        iv_str = a32_to_str([iv[0], iv[1], iv[0], iv[1]])
        forced_stop = False
        forced_stop_file = os.path.join( dest_path , "force_stop.tmp" )
        start = time.clock()
        dl = 0
        for chunk_start, chunk_size in sorted(get_chunks(file_size).items()):

            if os.path.exists( forced_stop_file ):
                forced_stop = True
                print "Forced stop"
                break

            chunk = input_file.read(chunk_size)
            chunk = aes.decrypt(chunk)
            output_file.write(chunk)
            
            encryptor = AES.new(k_str, AES.MODE_CBC, iv_str)
            dl += len(chunk)
            
            for i in range(0, len(chunk)-16, 16):
                block = chunk[i:i + 16]
                encryptor.encrypt(block)

            #fix for files under 16 bytes failing
            if file_size > 16:
                i += 16
            else:
                i = 0

            block = chunk[i:i + 16]
            if len(block) % 16:
                block += '\0' * (16 - (len(block) % 16))
            mac_str = mac_encryptor.encrypt(encryptor.encrypt(block))
            self.speed = float(float(dl)//float(time.clock() - start))
        file_mac = str_to_a32(mac_str)
        
        output_file.close()
        # check mac integrity
        #if (file_mac[0] ^ file_mac[1], file_mac[2] ^ file_mac[3]) != meta_mac:
        #    raise ValueError('Mismatched mac')
        
        if not forced_stop:
            pass
            # check mac integrity
            #if (file_mac[0] ^ file_mac[1], file_mac[2] ^ file_mac[3]) != meta_mac:
            #    raise ValueError('Mismatched mac')
        else:
            os.remove(forced_stop_file)
            os.remove(output_file_name)
            
    def get_filename(self,file_key,file_handle,is_public=False,file=None):
        if is_public:
            file_key = base64_to_a32(file_key)
            file_data = self.api_request({'a': 'g', 'g': 1, 'p': file_handle})
        else:
            file_data = self.api_request({'a': 'g', 'g': 1, 'n': file_handle})

        k = (file_key[0] ^ file_key[4], file_key[1] ^ file_key[5],
             file_key[2] ^ file_key[6], file_key[3] ^ file_key[7])
        iv = file_key[4:6] + (0, 0)
        meta_mac = file_key[6:8]

        file_url = file_data['g']
        file_size = file_data['s']
        attribs = base64_url_decode(file_data['at'])
        attribs = decrypt_attr(attribs, k)
        temp_file_name = attribs['n']
        
        return temp_file_name
    
    def process_file(self, file):
        """
        Process a file...
        """
        if file['t'] == 0 or file['t'] == 1:
            key = file['k'][file['k'].index(':') + 1:]
            key = decrypt_key(base64_to_a32(key), self.master_key)
            if file['t'] == 0:
                k = (key[0] ^ key[4], key[1] ^ key[5], key[2] ^ key[6],
                     key[3] ^ key[7])
                file['iv'] = key[4:6] + (0, 0)
                file['meta_mac'] = key[6:8]
            else:
                k = file['k'] = key
            attributes = base64_url_decode(file['a'])
            attributes = decrypt_attr(attributes, k)
            file['a'] = attributes
        elif file['t'] == 2:
            self.root_id = file['h']
            file['a'] = {'n': 'Cloud Drive'}
        elif file['t'] == 3:
            self.inbox_id = file['h']
            file['a'] = {'n': 'Inbox'}
        elif file['t'] == 4:
            self.trashbin_id = file['h']
            file['a'] = {'n': 'Rubbish Bin'}
        return file

    def get_public_url_info(self, url):
        """
        Get size and name from a public url, dict returned
        """
        file_handle, file_key = self._parse_url(url).split('!')
        return self.get_public_file_info(file_handle, file_key)

    def import_public_url(self, url, dest_node=None, dest_name=None):
        """
        Import the public url into user account
        """
        file_handle, file_key = self._parse_url(url).split('!')
        return self.import_public_file(file_handle, file_key, dest_node=dest_node, dest_name=dest_name)

    def _parse_url(self, url):
        #parse file id and key from url
        if '!' in url:
            match = re.findall(r'/#!(.*)', url)
            path = match[0]
            return path
        else:
            raise RequestError('Url key missing')
        
    def _api_request(self, data):
        params = {'id': self.sequence_num}
        self.sequence_num += 1

        if self.sid:
            params.update({'sid': self.sid})

        #ensure input data is a list
        if not isinstance(data, list):
            data = [data]

        req = requests.post(
            '{0}://g.api.{1}/cs'.format(self.schema, self.domain),
            params=params,
            data=json.dumps(data),
            timeout=self.timeout)
        json_resp = json.loads(req.text)

        #if numeric error code response
        if isinstance(json_resp, int):
            raise RequestError(json_resp)
        return json_resp[0]
    
    def get_public_file_info(self, file_handle, file_key):
        """
        Get size and name of a public file
        """
        data = self._api_request({
            'a': 'g',
            'p': file_handle,
            'ssm': 1})

        #if numeric error code response
        if isinstance(data, int):
            raise RequestError(data)

        if 'at' not in data or 's' not in data:
            raise ValueError("Unexpected result", data)

        key = base64_to_a32(file_key)
        k = (key[0] ^ key[4], key[1] ^ key[5], key[2] ^ key[6], key[3] ^ key[7])

        size = data['s']
        unencrypted_attrs = decrypt_attr(base64_url_decode(data['at']), k)
        if not unencrypted_attrs:
            return None

        result = {
            'size': size,
            'name': unencrypted_attrs['n']}

        return result

    def import_public_file(self, file_handle, file_key, dest_node=None, dest_name=None):
        """
        Import the public file into user account
        """

        # Providing dest_node spare an API call to retrieve it.
        if dest_node is None:
            # Get '/Cloud Drive' folder no dest node specified
            dest_node = self.get_node_by_type(2)[1]

        # Providing dest_name spares an API call to retrieve it.
        if dest_name is None:
            pl_info = self.get_public_file_info(file_handle, file_key)
            dest_name = pl_info['name']

        key = base64_to_a32(file_key)
        k = (key[0] ^ key[4], key[1] ^ key[5], key[2] ^ key[6], key[3] ^ key[7])

        encrypted_key = a32_to_base64(encrypt_key(key, self.master_key))
        encrypted_name = base64_url_encode(encrypt_attr({'n': dest_name}, k))

        data = self._api_request({
            'a': 'p',
            't': dest_node['h'],
            'n': [{
                'ph': file_handle,
                't': 0,
                'a': encrypted_name,
                'k': encrypted_key}]})

        #return API msg
        return data