# -*- coding: utf-8 -*-
#-----------------------------------------------------------------------------------------------
#Author: Hybrid
#Special thanks to XBMCHUB for developing the good old MEGA addon
import os
import sys
import urlparse
import urllib
import locale
import threading
import time
import shutil
import xbmc
import xbmcgui
import json
import bencode
import requests,urllib,urllib2
from bs4 import BeautifulSoup
import plugintools

REMOTE_DBG = False 

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append('C:\Users\Liron\AppData\Roaming\Kodi\system\python\Lib\pysrc')
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " + "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


# Get the platform and architecture
system_platform = 'Unknown'
architecture = ''

# struct.calcsize("P") is 4 or 8 for 32 or 64 bit Python repectively
# sys.maxsize > 2**32 would be nice to use but is only available from Pyton 2.6
#if struct.calcsize("P") == 8:
if sys.maxsize > 2**32:
    architecture = '64bit'
else:
    architecture = '32bit'

if xbmc.getCondVisibility( "system.platform.linux" ):
    system_platform = 'Linux'
    if 'arm' in os.uname()[4]:
        architecture = 'arm'
elif xbmc.getCondVisibility( "system.platform.xbox" ):
    system_platform = 'Xbox'
    # No architecture directory for Xbox
    architecture = ''
elif xbmc.getCondVisibility( "system.platform.windows" ):
    system_platform = 'Windows'

elif xbmc.getCondVisibility( "system.platform.osx" ):
    system_platform = 'Darwin'
    if 'RELEASE_ARM' in os.uname()[3]:
        architecture = 'ios'
    else:
        # Crypto can be compiled as universal library with multiple
        # architectures for osx
        architecture = 'osx'

elif xbmc.getCondVisibility( "system.platform.ios" ):
    # Need to check system.platform.osx for eden
    # Changed to system.platform.ios for frodo
    system_platform = 'Darwin'
    architecture = 'ios'

elif xbmc.getCondVisibility("system.platform.android"):
    system_platform = 'Android'
    architecture = 'arm'


crypto_path = os.path.join( plugintools.get_runtime_path(), "resources", "lib", "platform_libraries", system_platform, architecture)
plugintools.log("mega.init crypto_path="+crypto_path)
sys.path.append(crypto_path)

# Import other libraries
libraries = os.path.join( plugintools.get_runtime_path(), 'resources' , 'lib' )

sys.path.append (libraries)

try:
    from mega.mega import Mega
    
except:
    import traceback,sys
    from pprint import pprint
    exc_type, exc_value, exc_tb = sys.exc_info()
    lines = traceback.format_exception(exc_type, exc_value, exc_tb)
    for line in lines:
        line_splits = line.split("\n")
        for line_split in line_splits:
            plugintools.log(line_split) 
 
# Thumbnails for item list
NEXT_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'next.png' )
ALLMOVIES_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'all_movies.png' )
CATEGORIES_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'categories.png' )
SEARCH_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'search.png' )
CAT1_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'category1.png' )
CAT2_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'category2.png' )
CAT3_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'category3.png' )
CAT4_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'category4.png' )
CAT5_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'category5.png' )
CAT6_ICON = os.path.join( plugintools.get_runtime_path(), 'resources' , 'images' , 'category6.png' )
COVER = os.path.join( plugintools.get_runtime_path(),'fanart.jpg')

DOWNLOAD_PATH = plugintools.get_setting("download_path")
if DOWNLOAD_PATH == '':
    DOWNLOAD_PATH = os.path.join( plugintools.get_data_path() ,"downloads\\")


m=Mega()

    
# Entry point
def run():
    plugintools.log("mega.run")
    
    # Get params
    params = plugintools.get_params()
    plugintools.log("mega.run params="+repr(params))

    action = params.get("action")
    if action == 'all' :
        all_list(params)
    elif action == 'Next' :
        all_list(params)
    elif action == None:
        main_list()
    elif action == 'search':
        search()
    elif action == 'categories':
        categories()
    elif 'category' in action:
        show_category(action)
    elif 'megapulsar' in action:
        try:
            exec 'sendPulsar(params)'
        except:
            dialog = xbmcgui.Dialog()
            dialog.ok(u" שגיאה", u"לא ניתן לנגן סרט זה...")
    else:
        streamURL = params.get('url')
        if 'mega' in streamURL:
            try:
                exec action+"(params)"
            except:
                dialog = xbmcgui.Dialog()
                dialog.ok(u" שגיאה", u"לא ניתן לנגן סרט זה...")
        else:
            try:
                exec 'sendPulsar(params)'
            except:
                dialog = xbmcgui.Dialog()
                dialog.ok(u" שגיאה", u"לא ניתן לנגן סרט זה...")
    
    
def show_category(action):
    if '1' in action:
        getPage('http://sbs-3d.blogspot.co.il/search/label/%D7%A1%D7%A8%D7%98%D7%99%20%D7%AA%D7%9C%D7%AA-%D7%9E%D7%99%D7%9E%D7%93%20%D7%9E%D7%93%D7%95%D7%91%D7%91%D7%99%D7%9D%20%D7%9C%D7%A2%D7%91%D7%A8%D7%99%D7%AA')
    elif '2' in action:
        getPage('http://sbs-3d.blogspot.co.il/search/label/%D7%94%D7%A1%D7%A8%D7%98%D7%99%D7%9D%20%D7%94%D7%A0%D7%A6%D7%A4%D7%99%D7%9D%20%D7%91%D7%99%D7%95%D7%AA%D7%A8%20%D7%91-3D')
    elif '3' in action:
            getPage('http://sbs-3d.blogspot.co.il/search/label/%D7%A1%D7%A8%D7%98%D7%99%20%D7%AA%D7%9C%D7%AA%20%D7%9E%D7%99%D7%9E%D7%93%20%D7%A2%D7%9D%20%D7%AA%D7%A8%D7%92%D7%95%D7%9D%20%D7%9E%D7%95%D7%91%D7%A0%D7%94')
    elif '4' in action:
            getPage('http://sbs-3d.blogspot.co.il/search/label/%D7%A1%D7%A8%D7%98%D7%99%20%D7%90%D7%A0%D7%99%D7%9E%D7%A6%D7%99%D7%94%20%D7%95%D7%99%D7%9C%D7%93%D7%99%D7%9D%20%D7%91-3D')
    elif '5' in action:
            getPage('http://sbs-3d.blogspot.co.il/search/label/%D7%A1%D7%A8%D7%98%D7%99%D7%9D%20%D7%93%D7%95%D7%A7%D7%95%D7%9E%D7%A0%D7%98%D7%A8%D7%99%D7%99%D7%9D%20%D7%91-3D')
    elif '6' in action:
            getPage('http://sbs-3d.blogspot.co.il/search/label/%D7%91%D7%9C%D7%95-%D7%A8%D7%99%D7%99%203D%20%D7%9E%D7%9C%D7%90')

def categories():
    plugintools.add_item(action='category1',cover = COVER,title = u'מדובבים לעברית',thumbnail=CAT1_ICON)
    plugintools.add_item(action='category2',cover = COVER,title = u'הנצפים ביותר',thumbnail=CAT2_ICON)
    plugintools.add_item(action='category3',cover = COVER,title = u'תרגום מובנה',thumbnail=CAT3_ICON)
    plugintools.add_item(action='category4',cover = COVER,title = u'אנימציה וילדים',thumbnail=CAT4_ICON)
    plugintools.add_item(action='category5',cover = COVER,title = u'דוקומנטריים',thumbnail=CAT5_ICON)
    plugintools.add_item(action='category6',cover = COVER,title = u'בלוריי מלא',thumbnail=CAT6_ICON)
    
    plugintools.close_item_list()
    
def search():
    searchtext = ''
    keyboard = xbmc.Keyboard(searchtext,u"חיפוש סרט")
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        query = keyboard.getText()
        query = query
        getPage('http://sbs-3d.blogspot.co.il/search?q='+urllib.quote_plus(query))
        
# Main menu
def main_list():
    plugintools.add_item(action='search',cover = COVER,title = u'חיפוש',thumbnail=SEARCH_ICON)
    plugintools.add_item(action='all',cover = COVER,title = u'כל הסרטים',thumbnail=ALLMOVIES_ICON)
    plugintools.add_item(action='categories',cover = COVER,title = u'קטגוריות',thumbnail=CATEGORIES_ICON)
    plugintools.close_item_list()
    
def all_list(params):
    link = params.get('url')
    getPage(link)
    
def checkPulsarMega(url):
    details = getDetailsOfFile(url)
    if details['name'].endswith('.torrent'):
        return True
    else:
        return False
    
def getPage(Myurl = ''):
    if Myurl=='' or Myurl==None:
        Myurl='http://sbs-3d.blogspot.co.il/search?q='
    names =[]
    headers = {}
    headers['User-Agent']= 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/11.0.672.2 Safari/534.20'
    request = urllib2.Request(Myurl,headers=headers)
    resp = urllib2.urlopen(request)
    result = resp.read().decode('utf-8')
    soup = BeautifulSoup(result,'html.parser',from_encoding='utf-8')
    postList = soup.findAll('div',{'class':'post hentry'})
    for link in postList:
        image = link.find('meta',{'itemprop':'image_url'})
        name = link.find('h3',{'itemprop':'name'})
        if name!=None:
            name=name.a
        EnglishName = link.find('div',{'dir':'rtl','style':'text-align: right;','trbidi':'on'})
        EnglishName = EnglishName.h2
        if EnglishName != None:
            EnglishName = EnglishName.text
            EnglishName = EnglishName.replace('\n','')
                
        if EnglishName == None:
            EnglishName = link.find('h2',{'style':'text-align: right;'})
            if EnglishName != None:
                EnglishName = EnglishName.text
                EnglishName = EnglishName.replace('\n','')
        details = link.find('span',{'style':"font-weight: normal;"})
        if details == None:
            details = 'NOPE'
        else:
            details = details.text
        trailer = link.find('iframe')
        if trailer == None:
            trailer = ''
        else:
            trailer = trailer.get('src')
        if name != None and details != None and image != None and EnglishName !=None and EnglishName not in names:
            name = name.text.replace(u'להורדה','')
            image = image.get('content')
            linksList = link.findAll('a')
            for downLink in linksList:
                strm_link = downLink.get('href')
                if ('mega' in str(downLink.get('href')) or 'docs.google.com' in str(downLink.get('href'))) and EnglishName not in names:
                    '''
                    print '\n Add item'
                    print 'Name: '+name.encode('utf-8')
                    print 'Image: '+image.encode('utf-8')
                    print 'Link: '+strm_link.encode('utf-8')
                    print 'Plot: '+details.encode('utf-8')
                    print 'Trailer: '+trailer.encode('utf-8')
                    '''
                    
                    
                    
                    try:
                        EnglishName = EnglishName.encode('utf-8')
                        #sprint 'EnglishName: '+EnglishName
                    except: pass
                    names.append(EnglishName)
                    try:
                        mycover=getCover(EnglishName)
                    except:
                        mycover = COVER
                    try:
                        if 'mega' in strm_link or 'Mega' in strm_link:
                            if checkPulsarMega(strm_link):
                                name = name + '[COLOR green] [Torrent] [/COLOR]'
                                plugintools.add_item( action="megapulsar",cover = mycover,EnglishTitle = EnglishName,plot=details.encode('utf-8'),trailer = trailer, title=name.encode('utf-8') , url=strm_link , isPlayable=False, thumbnail=image , folder=False )
                            else:
                                name = name + '[COLOR red] [Mega] [/COLOR]'
                                plugintools.add_item( action="stream",cover = mycover,EnglishTitle = EnglishName,plot=details.encode('utf-8'),trailer = trailer, title=name.encode('utf-8') , url=strm_link , isPlayable=False, thumbnail=image , folder=False )
                        else:
                            name = name + '[COLOR green] [Torrent] [/COLOR]'
                            plugintools.add_item( action="stream",cover = mycover,EnglishTitle = EnglishName,plot=details.encode('utf-8'),trailer = trailer, title=name.encode('utf-8') , url=strm_link , isPlayable=False, thumbnail=image , folder=False )
                    except:
                        name = name + u'[COLOR blue] [לא זמין] [/COLOR]'
                        plugintools.add_item( action="stream",cover = mycover,EnglishTitle = EnglishName,plot=details.encode('utf-8'),trailer = trailer, title=name.encode('utf-8') , url=strm_link , isPlayable=False, thumbnail=image , folder=False )

                    #addDirectoryItem(name=name,isFolder=True,url=strm_link,iconimage=image,coverimage=None, parameters={ PARAMETER_KEY_MODE: 'stream','url':strm_link,'image':image,'title':EnglishName,'PrevMode':mode })
                    #print(repr(name))
    nextPage = soup.find('a',{'class':'blog-pager-older-link'})
    try:
        nextUrl = nextPage.get('href')
        plugintools.add_item( action='Next',cover = COVER, title='עמוד הבא' , url=nextUrl , isPlayable=False, thumbnail=NEXT_ICON , folder=True )
    except: nextUrl = ''
    plugintools.close_item_list()

def sendPulsar(params):
    maindialog = xbmcgui.DialogProgress()
    maindialog.create(u'מעבד', u'מחפש עבור הרחבת טורנט...')
    progress = 0
    maindialog.update(progress)
    
    torrentClient = plugintools.get_setting("torrent_client")
    clientName = ''
    if torrentClient == '0':
        clientName = 'plugin.video.pulsar'
    elif torrentClient == '1':
        clientName = 'plugin.video.kmediatorrent'
    if os.path.exists(xbmc.translatePath("special://home/addons/") + clientName):
        dirDel = os.listdir(DOWNLOAD_PATH)
        if 'play.torrent' in dirDel:
            full_path = os.path.join( DOWNLOAD_PATH , 'play.torrent' )
            os.remove(full_path)
            
        link = params.get('url')
        if 'google' in link:
            getDocsDownLink(link)
        elif 'mega' in link:
            download_thread = DownloadThread(link,True)
            download_thread.start()
            while download_thread.is_alive():
                xbmc.sleep(1000)
        file = DOWNLOAD_PATH+'play.torrent'
        #convert the torrent to magnet  take from http://stackoverflow.com/questions/12479570/given-a-torrent-file-how-do-i-generate-a-magnet-link-in-python
        torrent = open(file, 'rb').read()
        metadata = bencode.bdecode(torrent)
        hashcontents = bencode.bencode(metadata['info'])
        import hashlib
        digest = hashlib.sha1(hashcontents).digest()
        import base64
        b32hash = base64.b32encode(digest)
        
        maindialog.close()
        if 'pulsar' in clientName:
            magneturi = 'magnet:?xt=urn:btih:' + b32hash
            xbmc.executebuiltin( "PlayMedia(plugin://plugin.video.pulsar/play?uri=%s)" % magneturi)
        elif 'kmediatorrent' in clientName:
            magneturi = 'magnet%3A%3Fxt%3Durn%3Abtih%3A' + b32hash
            xbmc.executebuiltin( "PlayMedia(plugin://plugin.video.kmediatorrent/play/%s)" % magneturi)
    else:
        maindialog.close()
        dialog = xbmcgui.Dialog()
        dialog.ok(u" שגיאה", u"אנא התקן או הגדר בהגדרות ההרחבה תוסף טורנט מתאים")
    
    
def getDocsDownLink(url):
    if 'https://docs.google.com/file/d/' in url:
        url = url[len('https://docs.google.com/file/d/'):]
    if url.endswith('/edit'):
        url = url[:-5]
    headers = {}
    headers['User-Agent']= 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/11.0.672.2 Safari/534.20'

    request = urllib2.Request('https://www.googleapis.com/drive/v2/files/'+url+'?key=AIzaSyBvnlwCVhkSXOdTtkuW_XBvQoeyKjn53EE')
    resp = urllib2.urlopen(request)
    result = resp.read()
    json_obj = json.loads(result)
    link = json_obj.get('downloadUrl').replace('?e=download&gd=true','')
    #print link
    
    res= requests.request(method='GET', url=link)
    url = json_obj.get('webContentLink')
    
    r = requests.get(url, stream=True)
    file_name = DOWNLOAD_PATH+'play.torrent'
    with open(file_name, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024): 
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
                    f.flush()
    f.close()
 
def getCover(title):   
    title = cleanTitle(title)
    url = 'http://api.themoviedb.org/3/search/movie?api_key=57983e31fb435df4df77afb854740ea9&query='+urllib.quote_plus(title)
    headers = {}
    headers['User-Agent']= 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/11.0.672.2 Safari/534.20'

    request = urllib2.Request(url)
    resp = urllib2.urlopen(request)
    result = resp.read()
    json_obj = json.loads(result)
    
    movie = json_obj['results'][0]
    return 'https://image.tmdb.org/t/p/original'+movie.get('backdrop_path')
    
def cleanTitle(title):
    title = title.replace('3D','')
    title = title.replace('Half-SBS','')
    title = title.replace('1080p','')
    title = title.replace('HebSub','')
    title = title.replace('BluRay','')
    title = title.replace('Half-OU','')
    title = title.replace('Dubbed','')
    title = title.replace('Hebrew','')
    
    return title
def human_size(size):

    if size<1024:
        text_size="%dB" % size
    elif size<(1024*1024):
        text_size="%dKB" % (size / 1024)
    elif size<(1024*1024*1024):
        text_size="%dMB" % (size / (1024*1024) )
    elif size<(1024*1024*1024*1024):
        text_size="%dGB" % (size / (1024*1024*1024) )
    else:
        text_size="%dTB" % (size / (1024*1024*1024*1024) )

    return text_size

def getDetailsOfFile(url):
        '''
        Download a file by it's public url
        '''
        path = m.parse_url(url).split('!')
        file_id = path[0]
        file_key = path[1]
        return m.file_details(file_id, file_key, is_public=True)

def parse_url(self, url):
        #parse file id and key from url
        if ('!' in url):
            match = re.findall(r'/#!(.*)', url)
            path = match[0]
            return path
        else:
            raise errors.RequestError('Url key missing')


# Download a file and start playing while downloading
def stream(params):
        stream_url = params.get('url')
        image = params.get('thumbnail')
        title = params.get('title')
        plugintools.log("mega.stream "+stream_url)
        
        maindialog = xbmcgui.DialogProgress()
        maindialog.create('Accessing MEGA', 'Initializing...')
        progress = 0
        maindialog.update(progress)
        maindialog.update(100)
        maindialog.close()
    
        if not os.path.exists( DOWNLOAD_PATH ):
            os.makedirs(DOWNLOAD_PATH)
        plugintools.log("mega.stream DOWNLOAD_PATH="+DOWNLOAD_PATH)
        
        #ensuring that there is no download thread active
        force_stop_file = open( os.path.join( DOWNLOAD_PATH , "force_stop.tmp" ) , "w" )
        force_stop_file.write("0")
        force_stop_file.close()
        
        
        # Delete existing files from download folder
        dirDel = os.listdir(DOWNLOAD_PATH)
        if 'Play.3D.SBS.mkv' in dirDel:
            full_path = os.path.join( DOWNLOAD_PATH , 'Play.3D.SBS.mkv' )
            plugintools.log("mega.stream Deleting " + full_path)
            os.remove(full_path)
        if 'force_stop.tmp' in dirDel:
            full_path = os.path.join( DOWNLOAD_PATH , 'force_stop.tmp' )
            plugintools.log("mega.stream Deleting " + full_path)
            os.remove(full_path)
    
        file = stream_url
        ##############################################################################################################################
        
        plugintools.log("mega.stream file="+repr(file))
        maindialog.close()
    
        # Lanza thread
        plugintools.log("mega.stream Active threads "+str(threading.active_count()))
        plugintools.log("mega.stream "+repr(threading.enumerate()))
        plugintools.log("mega.stream Starting download thread...")
    
        #file[1]['a']['n']='Play.mkv'
        
        
        download_thread = DownloadThread(file)
        download_thread.start()
        plugintools.log("mega.stream Download thread started")
        plugintools.log("mega.stream Active threads "+str(threading.active_count()))
        plugintools.log("mega.stream "+repr(threading.enumerate()))
    
        # Espera
        plugintools.log("mega.stream Waiting...")
    
        dialog = xbmcgui.DialogProgress()
        dialog.create(u'מזרים קובץ', u'טוען את הקובץ לפני ניגון...')
        progress = 0
        totalsize = getDetailsOfFile(stream_url)
        if totalsize != None:
            totalsize = totalsize['size']
        else: totalsize = 10000
        sizeofFileinMB = (float(totalsize)/1000000)
        
        buffering_time = int(plugintools.get_setting("buffering_size"))
        if buffering_time > sizeofFileinMB:
            buffering_time = sizeofFileinMB
        plugintools.log("mega.stream buffering_socket="+str(buffering_time))
        dialog.update(progress)

        cancelled=False

        fileExist = False
        while progress <= 100:
            if 'Play.3D.SBS.mkv' in os.listdir(DOWNLOAD_PATH):
                fileExist = True
            if fileExist:
                filesize = float(os.stat(DOWNLOAD_PATH+'Play.3D.SBS.mkv').st_size)
                progress = int( ((filesize/1000000) / float(buffering_time))*100)
                downloaded = title+' Downloaded: ('+m.human_size(filesize)+' / '+m.human_size(totalsize)+') Speed: '+m.human_size(m.speed)+'/s'
                dialog.update(progress,downloaded )
                
                #######################################################################################################################
                #xbmc.sleep(10000)
                xbmc.sleep(1000)
                #######################################################################################################################
                
                plugintools.log("mega.stream progress="+str(progress))
            if dialog.iscanceled():
                cancelled=True
                break
    
        dialog.close()
    
        plugintools.log("mega.stream End of waiting")
    
        player = CustomPlayer()
        
        if not cancelled:
            local_file = os.path.join( DOWNLOAD_PATH , 'Play.3D.SBS.mkv' )
            plugintools.log("mega.stream Playing -public url-... " + 'Play.3D.SBS.mkv')
               
            player.set_download_thread(download_thread)
            player.PlayStream(local_file,title,image,'Video',totalsize)
            xbmc.sleep(3000)
            
        while player.isPlaying():
                xbmc.sleep(1000)
                plugintools.log("mega.play Download thread alive="+str(download_thread.is_alive()))

        if download_thread.is_alive():
            plugintools.log("mega.stream Killing download thread")
            download_thread.force_stop()

class CustomPlayer(xbmc.Player):
    def __init__( self, *args, **kwargs ):
        plugintools.log("mega.CustomPlayer.__init__")
        xbmc.Player.__init__( self )

    def PlayStream(self,link,title, thumbnail, mediaType='Video',totalsize=0) :
        """Plays a video
       
        Arguments:
        title: the title to be displayed
        thumbnail: the thumnail to be used as an icon and thumbnail
        link: the link to the media to be played
        mediaType: the type of media to play, defaults to Video. Known values are Video, Pictures, Music and Programs
        """
        plugintools.log("mega.CustomPlayer.PlayStream url="+link)
        
        li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail, path=link)
        li.setInfo(type=mediaType, infoLabels={ "Title": str(title) })
        
        #from mega.onscreen_label import OverlayText
        #onscreen_label = OverlayText('LIROYYYYY')
        
        self.play(item=link, listitem=li)
        while self.isPlaying():
            '''
            if xbmc.getCondVisibility('Player.Paused'):
                filesize = float(os.stat(DOWNLOAD_PATH+'Play.3D.SBS.mkv').st_size)
                progress = int( ((filesize/1000000) / float(totalsize))*100)
                downloaded = title+' '+progrss+'% Downloaded: ('+m.human_size(filesize)+' / '+m.human_size(totalsize)+') Speed: '+m.human_size(m.speed)+'/s'
                onscreen_label.text = downloaded
                onscreen_label.show()
            else:
                onscreen_label.hide()
            '''
            xbmc.sleep(3000)
            

    def set_download_thread(self,download_thread):
        plugintools.log("mega.CustomPlayer.set_download_thread")
        self.download_thread = download_thread

    def force_stop_download_thread(self):
        plugintools.log("mega.CustomPlayer.force_stop_download_thread")

        if self.download_thread.is_alive():
            plugintools.log("mega.CustomPlayer.force_stop_download_thread Killing download thread")
            self.download_thread.force_stop()

            #while self.download_thread.is_alive():
            #    xbmc.sleep(1000)

    def onPlayBackStarted(self):
        plugintools.log("mega.CustomPlayer.onPlayBackStarted PLAYBACK STARTED")

    def onPlayBackEnded(self):
        plugintools.log("mega.CustomPlayer.onPlayBackEnded PLAYBACK ENDED")

    def onPlayBackStopped(self):
        plugintools.log("mega.CustomPlayer.onPlayBackStopped PLAYBACK STOPPED")
        self.force_stop_download_thread()

# Download in background
class DownloadThread(threading.Thread):
    
    def __init__(self, file,torrent=False):
        plugintools.log("mega.DownloadThread.__init__ "+repr(file))

        self.file = file        
        self.torrent = torrent
        threading.Thread.__init__(self)
        
    def run(self):
        plugintools.log("mega.DownloadThread.run Download starts..." + repr(self.file))

        if self.torrent:
            m.download_url_torrent(self.file,DOWNLOAD_PATH,'play.torrent')
        elif 'https:' in repr(self.file):
           plugintools.log("mega.DownloadThread.run.... public url streaming")
           m.download_url(self.file , DOWNLOAD_PATH)
        else:
           plugintools.log("mega.DownloadThread.run.... private url streaming")
           m.download(self.file , DOWNLOAD_PATH)

        plugintools.log("mega.DownloadThread.run Download ends")

    def force_stop(self):
        plugintools.log("mega.DownloadThread.force_stop...")
        force_stop_file = open( os.path.join( DOWNLOAD_PATH , "force_stop.tmp" ) , "w" )
        force_stop_file.write("0")
        force_stop_file.close()

run()