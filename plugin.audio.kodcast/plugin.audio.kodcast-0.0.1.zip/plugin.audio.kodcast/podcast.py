import re


class Podcast:
    def __init__(self, name, image, url, description):
        self.id = re.search('&id=(\d+)', url).group(1)
        self.name = name
        self.image = image
        self.url = url
        self.description = description
