import xbmcaddon

ADDON_ID = 'plugin.audio.kodcast'
BASE_URL = 'http://www.icast.co.il'
MEDIA_PATH = 'special://home/addons/{0}/resources/media'