import sys
import cache
import urllib
import urllib2
import urlparse
import xbmc
import xbmcgui
import xbmcplugin
import json


@cache.cache
def get_json():
    return urllib2.urlopen('http://nirelbaz.com/kodi/data/playlists.json').read().decode("utf-8")


# Get addon's base URL:
base_url = sys.argv[0]
# Get addon's process handle:
addon_handle = int(sys.argv[1])
# Get query string passed to addon:
args = urlparse.parse_qs(sys.argv[2][1:])
# Get playlists data:
json_str = urllib2.urlopen('http://nirelbaz.com/kodi/data/playlists.json').read().decode("utf-8")
python_dict = json.loads(json_str)
# Audio plugin:
xbmcplugin.setContent(addon_handle, 'audio')
# Set initial mode:
mode = args.get('mode', None)
# Set view mode:
xbmc.executebuiltin("Container.SetViewMode(64)")


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


# draw folders:
if mode is None:
    for idx, category in enumerate(python_dict):
        url = build_url({'mode': 'folder', 'findex': idx})
        li = xbmcgui.ListItem(category['title'].upper() + ' - ' + category['slogan'], iconImage=category['bgImage'])
        li.setArt({'poster': category['bgImage'], 'thumb': category['bgImage'], 'fanart': category['bgImage']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


# draw playlists:
elif mode[0] == 'folder':
    folder_index = int(args['findex'][0])

    for idx, playlist in enumerate(python_dict[folder_index]['playlists']):
        li = xbmcgui.ListItem(playlist['title'] + ' - ' + playlist['slogan'], playlist['bgImage'])
        li.setArt({'poster': playlist['bgImage'], 'thumb': playlist['bgImage'], 'fanart': playlist['bgImage']})
        li.setInfo('music', {'Title': playlist['title'], 'Artist': playlist['slogan']})
        li.setProperty('mimetype', 'audio/mpeg')
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=urllib.quote(playlist['audio'], safe=':/?='), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)
