# This will contain the main Python code for your add-on.
# You can name it whatever you want, since you'll define this
# Python file in addon.xml as your main script file.
#
# ---------------------------------------
# Built-in modules, uncomment if you need.
#
#

import sys
import urllib
import urllib2
import urlparse
import xbmcgui
import xbmcplugin
import json
# import xbmcaddon
# import xbmcvfs

# Get addon's base URL:
base_url = sys.argv[0]
# Get addon's process handle:
addon_handle = int(sys.argv[1])
# Get query string passed to addon:
args = urlparse.parse_qs(sys.argv[2][1:])
# Get playlists data:
json_str = urllib2.urlopen('http://nirelbaz.com/data/playlists.json').read().decode("utf-8")
python_dict = json.loads(json_str)

xbmcplugin.setContent(addon_handle, 'audio')

def build_url(query):
  return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

# draw folders:
if mode is None:
  for idx, category in enumerate(python_dict):
    url = build_url({ 'mode': 'folder', 'folderindex': idx })
    li = xbmcgui.ListItem(category['title'].upper() + ' - ' + category['slogan'], iconImage=category['bgImage'])
    li.setArt({ 'poster': category['bgImage'], 'thumb': category['bgImage'], 'fanart': category['bgImage'] })
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

  xbmcplugin.endOfDirectory(addon_handle)

# draw playlists:
elif mode[0] == 'folder':
  folderindex = int(args['folderindex'][0])

  for idx, playlist in enumerate(python_dict[folderindex]['playlists']):
    url = urllib.quote(playlist['mp3'], safe=':/?=')
    li = xbmcgui.ListItem(playlist['title'], playlist['bgImage'])
    li.setArt({ 'poster': playlist['bgImage'], 'thumb': playlist['bgImage'], 'fanart': playlist['bgImage'] })
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

  xbmcplugin.endOfDirectory(addon_handle)